package Modelo;

import Excepciones.DatoInvalidoException;
import Excepciones.NominaException;

public abstract class Empleado {
    private String nombre;
    private int id;

    public Empleado(String nombre, int id) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new DatoInvalidoException("El nombre no puede estar vacio");
        }
        this.nombre = nombre;
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getId() {
        return id;
    }

    public abstract double calcularPago() throws NominaException;

    public abstract String getTipo();

    @Override
    public String toString() {
        return id + " " + nombre + " (" + getTipo() + ")";
    }
}
