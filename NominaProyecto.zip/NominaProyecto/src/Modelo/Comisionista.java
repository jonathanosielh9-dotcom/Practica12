package Modelo;

import Excepciones.DatoInvalidoException;

public class Comisionista extends Empleado {
    private static final double COMISION = 0.08;

    private double sueldoBase;
    private double ventas;

    public Comisionista(String nombre, int id, double sueldoBase, double ventas) {
        super(nombre, id);
        if (sueldoBase < 0) {
            throw new DatoInvalidoException("El sueldo base no puede ser negativo: " + sueldoBase);
        }
        if (ventas < 0) {
            throw new DatoInvalidoException("Las ventas no pueden ser negativas: " + ventas);
        }
        this.sueldoBase = sueldoBase;
        this.ventas = ventas;
    }

    @Override
    public double calcularPago() {
        return sueldoBase + ventas * COMISION;
    }

    @Override
    public String getTipo() {
        return "Comisionista";
    }
}
