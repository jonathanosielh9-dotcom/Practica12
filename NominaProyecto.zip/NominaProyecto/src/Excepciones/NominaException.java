package Excepciones;

public class NominaException extends Exception {

    public NominaException(String mensaje) {
        super(mensaje);
    }
}
