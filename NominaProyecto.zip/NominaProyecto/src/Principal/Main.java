package Principal;

import Excepciones.DatoInvalidoException;
import Excepciones.NominaException;
import Modelo.Comisionista;
import Modelo.Empleado;
import Modelo.EmpleadoPorHoras;
import Modelo.EmpleadoPorSueldo;

public class Main {
    public static void main(String[] args) {
        System.out.println("----- Alta de empleados con datos invalidos -----");
        try {
            new EmpleadoPorSueldo("", 10, 12000);
        } catch (DatoInvalidoException e) {
            System.out.println("  No se registro: " + e.getMessage());
        }
        try {
            new EmpleadoPorHoras("Pedro", 11, -50);
        } catch (DatoInvalidoException e) {
            System.out.println("  No se registro: " + e.getMessage());
        }
        try {
            new Comisionista("Rosa", 12, 7000, -2000);
        } catch (DatoInvalidoException e) {
            System.out.println("  No se registro: " + e.getMessage());
        }

        EmpleadoPorHoras luis = new EmpleadoPorHoras("Luis", 2, 100);
        EmpleadoPorHoras marta = new EmpleadoPorHoras("Marta", 3, 100);
        EmpleadoPorHoras jorge = new EmpleadoPorHoras("Jorge", 4, 100);
        luis.setHoras(150);
        marta.setHoras(180);
        jorge.setHoras(320);

        Empleado[] nomina = {
            new EmpleadoPorSueldo("Ana", 1, 18000),
            luis,
            marta,
            jorge,
            new Comisionista("Sara", 5, 7000, 50000)
        };

        System.out.println("----- Calculo de la nomina -----");
        double total = 0;
        int conError = 0;
        for (Empleado e : nomina) {
            try {
                double pago = e.calcularPago();
                total += pago;
                System.out.printf("  %-26s $%,10.2f%n", e, pago);
            } catch (NominaException ex) {
                conError++;
                System.out.println("  [Error] " + ex.getMessage());
            }
        }
        System.out.printf("Total de la nomina: $%,.2f%n", total);
        System.out.println("Empleados pendientes por error: " + conError);
    }
}
